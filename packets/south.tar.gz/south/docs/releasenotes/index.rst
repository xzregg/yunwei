Release Notes
=============

Release notes from various versions of South.

.. toctree::
   :maxdepth: 1
   
   0.7
   0.7.1
   0.7.2
   0.7.3
   0.7.4
   0.7.5
   0.7.6
   0.8
   0.8.1
   0.8.2
